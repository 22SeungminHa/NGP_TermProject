#include"stdafx.h"
#include "ServerManager.h"

ServerManager s_mng;

int main()
{
	
}
